# HaloDiscussionReader
A simple Chrome extension that marks all posts as read on a Halo discussion board.

## To use:
1. Download the HaloDiscussion.zip and unpack it.
2. In Chrome, go to chrome://extensions and toggle the "Developer Tools" switch to 'on'
3. Select "Load Unpacked" and upload the unzipped directory.
4. Go to Halo discussions and click the extension icon. All posts for that discussion should be marked as read.
