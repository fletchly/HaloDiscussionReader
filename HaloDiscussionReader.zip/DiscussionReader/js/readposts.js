var buttons = document.getElementsByClassName('ReadTag_unreadTag__wOiQG');

for(var i = 0; i < buttons.length; i++)
buttons[i].click();